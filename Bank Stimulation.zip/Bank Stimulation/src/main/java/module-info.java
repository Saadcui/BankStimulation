module com.example.bankstimulation {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bankstimulation to javafx.fxml;
    exports com.example.bankstimulation;
}