package com.example.bankstimulation;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class HelloApplication extends Application {
    User loggedInUser;
    @Override
    public void start(Stage stage) throws IOException {


        UserList userList = new UserList();
        Scene scene,scene1,scene2,scene3,scene4;
        stage.setTitle("Bank Stimulation");
        //create account
        GridPane createAccount=new GridPane();
        Label label1 = new Label("Create Account");
        Font font1 = new Font("Times New Roman", 22);
        label1.setFont(font1);

        scene2= new Scene(createAccount, 600, 400);


        Label nameLabel = new Label("Name:");
        nameLabel.setStyle("-fx-font-weight: bold");
        Label mobileLabel = new Label("Phone number:");
        mobileLabel.setStyle("-fx-font-weight: bold");
        Label cnicLabel = new Label("CNIC:");
        cnicLabel.setStyle("-fx-font-weight: bold");
        Label usernameLabel = new Label("Username:");
        usernameLabel.setStyle("-fx-font-weight: bold");
        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-font-weight: bold");
        Label emailLabel = new Label("Email:");
        emailLabel.setStyle("-fx-font-weight: bold");
        Label balanceLabel = new Label("Initial Balance:");
        balanceLabel.setStyle("-fx-font-weight: bold");

        // TextFields
        TextField nameField = new TextField();
        TextField mobileField = new TextField();
        TextField cnicField = new TextField();
        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        TextField emailField = new TextField();
        TextField balanceField = new TextField();


        // Button
        Button createAccountButton = new Button("Create Account");
        createAccountButton.setPrefWidth(100);
        Button back=new Button("Back");
        back.setPrefWidth(60);



        createAccountButton.setOnAction(e -> {
            String name = nameField.getText();
            String mobilePhone = mobileField.getText();
            String cnic = cnicField.getText();
            String username = usernameField.getText();
            String password = passwordField.getText();
            String email = emailField.getText();
            int balance = 0;
            try {
                balance = Integer.parseInt(balanceField.getText());
                if (balance <= 0) {
                    // Show an error message or handle the case where balance is not valid
                    System.out.println("Balance should be greater than 0");
                    return; // Stop further execution if balance is invalid
                }
            } catch (NumberFormatException ex) {
                // Handle non-integer input for balance field
                System.out.println("Please enter a valid number for balance");
                return; // Stop further execution if balance is not a valid number
            }


            System.out.println("Name: " + name);
            System.out.println("Mobile Phone: " + mobilePhone);
            System.out.println("CNIC: " + cnic);
            System.out.println("Username: " + username);
            System.out.println("Password: " + password);
            System.out.println("Email: " + email);
            System.out.println("Balance: " + balance);



            userList.createAccount(name, mobilePhone, cnic, username, password, email, balance);
        });






        Button signUpbutton=new Button("or SignUp");
        signUpbutton.setMaxWidth(200);
        signUpbutton.setOnAction(e->{stage.setScene(scene2);});




        stage.setTitle("Bank Stimulation");
        double buttonWidth = 140, buttonHeight = 20;


        GridPane login = new GridPane();
        Label label = new Label("LOGIN ");
        Font font = new Font("Times New Roman", 22);
        label.setFont(font);


        scene1 = new Scene(login, 600, 400);
        Label UserName = new Label("Username: ");
        UserName.setPrefSize(70, buttonHeight);
        Label Password = new Label("Password: ");
        Password.setPrefSize(70, buttonHeight);
        TextField username = new TextField();
        PasswordField password = new PasswordField();
        Button lgIn = new Button("Login");
        lgIn.setMaxWidth(200);
        UserName.setStyle("-fx-font-weight: bold;");
        label.setStyle("-fx-font-weight: bold;");
        Password.setStyle("-fx-font-weight: bold;");
        lgIn.setPrefSize(60, 20);
        login.add(label, 1, 0);
        login.setVgap(5);
        login.add(UserName, 0, 1);
        login.add(username, 1, 1);
        login.add(Password, 0, 2);
        login.add(password, 1, 2);
        login.add(lgIn, 1, 3);
        login.add(signUpbutton, 1, 4);
        login.setAlignment(Pos.CENTER);





        back.setOnAction(e->stage.setScene(scene1));
        createAccount.setAlignment(Pos.CENTER);
        createAccount.setVgap(5);
        createAccount.setHgap(5);

        createAccount.add(nameLabel, 0, 0);
        createAccount.add(nameField, 1, 0);
        createAccount.add(mobileLabel, 0, 1);
        createAccount.add(mobileField, 1, 1);
        createAccount.add(cnicLabel, 0, 2);
        createAccount.add(cnicField, 1, 2);
        createAccount.add(usernameLabel, 0, 3);
        createAccount.add(usernameField, 1, 3);
        createAccount.add(passwordLabel, 0, 4);
        createAccount.add(passwordField, 1, 4);
        createAccount.add(emailLabel, 0, 5);
        createAccount.add(emailField, 1, 5);
        createAccount.add(balanceLabel, 0, 6);
        createAccount.add(balanceField, 1, 6);
        createAccount.add(createAccountButton, 0, 7);
        createAccount.add(back,1,7);





        GridPane operationsMenu = new GridPane();
        Scene operationsScene = new Scene(operationsMenu, 600, 400);
        Label operationsLabel = new Label("Operations Menu");
        operationsLabel.setFont(new Font("Times New Roman", 22));
        operationsMenu.setAlignment(Pos.CENTER);
        operationsMenu.setVgap(10);



        lgIn.setOnAction(e -> {
            // Retrieve the entered username and password from their respective fields
            String enteredUsername = username.getText();
            String enteredPassword = password.getText();


            loggedInUser = userList.login(enteredUsername, enteredPassword);

            // Check if the login was successful
            if (loggedInUser != null) {
                // If successful, print a message indicating successful login
                System.out.println("Login successful!");
                stage.setScene(operationsScene);
            } else {
                // If unsuccessful, print an error message indicating invalid credentials
                System.out.println("Invalid username or password.");

            }
        });



        Button withdrawButton = new Button("Withdraw");
        withdrawButton.setPrefWidth(200);
        withdrawButton.setOnAction(e -> {
            Stage withdrawStage = new Stage();
            GridPane withdrawPane = new GridPane();
            withdrawPane.setAlignment(Pos.CENTER);
            withdrawPane.setPadding(new Insets(20));

            Label withdrawLabel = new Label("Enter Withdrawal Amount:");
            TextField withdrawAmountField = new TextField();
            Button confirmWithdrawButton = new Button("Withdraw");

            confirmWithdrawButton.setOnAction(confirmEvent -> {
                try {
                    int amount = 0;
                    try {
                        amount = Integer.parseInt(withdrawAmountField.getText());
                        if (amount <= 0) {
                            System.out.println("Withdrawal amount should be greater than 0");
                            return; // Stop further execution if the amount is invalid
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("Please enter a valid number for withdrawal amount");
                        return; // Stop further execution if the amount is not a valid number
                    }

                    boolean isWithdrawn = loggedInUser.withdraw(amount);
                    if (isWithdrawn) {
                        System.out.println(amount + " withdrawn successfully. Current balance: " + loggedInUser.getBalance());
                        withdrawStage.close();
                        // Additional actions upon successful withdrawal
                    } else {
                        System.out.println("Insufficient balance or invalid amount for withdrawal.");
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Please enter a valid amount.");
                }
            });

            withdrawPane.add(withdrawLabel, 0, 0);
            withdrawPane.add(withdrawAmountField, 0, 1);
            withdrawPane.add(confirmWithdrawButton, 0, 2);

            Scene withdrawScene = new Scene(withdrawPane, 300, 200);
            withdrawStage.setScene(withdrawScene);
            withdrawStage.show();
        });


        Button depositButton = new Button("Deposit");
        depositButton.setPrefWidth(200);
        depositButton.setOnAction(e -> {
            Stage depositStage = new Stage();
            GridPane depositPane = new GridPane();
            depositPane.setAlignment(Pos.CENTER);
            depositPane.setPadding(new Insets(20));

            Label depositLabel = new Label("Enter Deposit Amount:");
            TextField depositAmountField = new TextField();
            Button confirmDepositButton = new Button("Deposit");

            confirmDepositButton.setOnAction(confirmEvent -> {
                try {
                    int amount = 0;
                    try {
                        amount = Integer.parseInt(depositAmountField.getText());
                        if (amount <= 0) {
                            System.out.println("Withdrawal amount should be greater than 0");
                            return; // Stop further execution if the amount is invalid
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("Please enter a valid number for withdrawal amount");
                        return; // Stop further execution if the amount is not a valid number
                    }
                    if (amount > 0) {
                        loggedInUser.deposit(amount);
                        System.out.println(amount + " deposited successfully. Current balance: " + loggedInUser.getBalance());
                        depositStage.close();
                        // Additional actions upon successful deposit
                    } else {
                        System.out.println("Invalid deposit amount.");
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Please enter a valid amount.");
                }
            });

            depositPane.add(depositLabel, 0, 0);
            depositPane.add(depositAmountField, 0, 1);
            depositPane.add(confirmDepositButton, 0, 2);

            Scene depositScene = new Scene(depositPane, 300, 200);
            depositStage.setScene(depositScene);
            depositStage.show();
        });
        Button transferButton = new Button("Transfer");
        transferButton.setPrefWidth(200);
        transferButton.setOnAction(e -> {
            Stage transferStage = new Stage();
            GridPane transferPane = new GridPane();
            transferPane.setAlignment(Pos.CENTER);
            transferPane.setPadding(new Insets(20));

            Label transferLabel = new Label("Enter Transfer Amount:");
            TextField transferAmountField = new TextField();
            Label recipientLabel = new Label("Enter Recipient Username:");
            TextField recipientField = new TextField();
            Button confirmTransferButton = new Button("Transfer");

            confirmTransferButton.setOnAction(confirmEvent -> {
                try {
                    int amount = 0;
                    try {
                        amount = Integer.parseInt(transferAmountField.getText());
                        if (amount <= 0) {
                            System.out.println("Withdrawal amount should be greater than 0");
                            return; // Stop further execution if the amount is invalid
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("Please enter a valid number for withdrawal amount");
                        return; // Stop further execution if the amount is not a valid number
                    }
                    String recipientUsername = recipientField.getText();

                    // Fetch recipient User based on username
                    User recipient = userList.searchUserByName(recipientUsername);

                    if (recipient != null && amount > 0) {
                        boolean isTransferred = loggedInUser.moneyTransfer(recipient, amount);
                        if (isTransferred) {
                            System.out.println(amount + " transferred successfully to " + recipient.getUsername());
                            transferStage.close();
                            // Additional actions upon successful transfer
                        } else {
                            System.out.println("Transfer failed. Insufficient balance.");
                        }
                    } else {
                        System.out.println("Invalid recipient or transfer amount.");
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Please enter a valid amount.");
                }
            });

            transferPane.add(transferLabel, 0, 0);
            transferPane.add(transferAmountField, 0, 1);
            transferPane.add(recipientLabel, 0, 2);
            transferPane.add(recipientField, 0, 3);
            transferPane.add(confirmTransferButton, 0, 4);

            Scene transferScene = new Scene(transferPane, 350, 250);
            transferStage.setScene(transferScene);
            transferStage.show();
        });

        Button loanOperationsButton = new Button("Loan Operations");
        loanOperationsButton.setPrefWidth(200);
        loanOperationsButton.setOnAction(e -> {
            Stage loanStage = new Stage();
            GridPane loanPane = new GridPane();
            loanPane.setAlignment(Pos.CENTER);
            loanPane.setPadding(new Insets(20));

            Label loanMenuLabel = new Label("Loan Operations Menu:");
            loanMenuLabel.setStyle("-fx-font-weight: bold");
            Button applyForLoanButton = new Button("Apply for a loan");
            applyForLoanButton.setPrefWidth(200);
            applyForLoanButton.setOnAction(applyEvent -> {
                Stage applyForLoanStage = new Stage();
                GridPane applyForLoanPane = new GridPane();
                applyForLoanPane.setAlignment(Pos.CENTER);
                applyForLoanPane.setPadding(new Insets(20));

                Label loanRequestLabel = new Label("Apply for a Loan");
                Label requestedAmountLabel = new Label("Enter the requested amount:");
                TextField requestedAmountField = new TextField();
                Button requestLoanButton = new Button("Request Loan");



                Queue<Integer> loanRequests = loggedInUser.getLoanRequests();
                int userBalance = loggedInUser.getBalance();

                requestLoanButton.setOnAction(requestEvent -> {
                    try {
                        int requestedAmount = 0;
                        try {
                            requestedAmount = Integer.parseInt(requestedAmountField.getText());
                            if (requestedAmount <= 0) {
                                System.out.println("Withdrawal amount should be greater than 0");
                                return; // Stop further execution if the amount is invalid
                            }
                        } catch (NumberFormatException ex) {
                            System.out.println("Please enter a valid number for withdrawal amount");
                            return; // Stop further execution if the amount is not a valid number
                        }

                        if (!loanRequests.isEmpty()) {
                            System.out.println("Loan request denied. You have pending dues.");
                            applyForLoanStage.close();
                            return;
                        }

                        if (requestedAmount <= 2 * userBalance) {
                            System.out.println("Loan request approved. Amount: " + requestedAmount);
                            loanRequests.offer(requestedAmount);
                            applyForLoanStage.close();
                            // Additional actions upon successful loan request
                        } else {
                            System.out.println("Loan request denied. Requested amount exceeds the allowed limit.");
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("Please enter a valid amount.");
                    }
                });

                applyForLoanPane.add(loanRequestLabel, 0, 0);
                applyForLoanPane.add(requestedAmountLabel, 0, 1);
                applyForLoanPane.add(requestedAmountField, 0, 2);
                applyForLoanPane.add(requestLoanButton, 0, 3);

                Scene applyForLoanScene = new Scene(applyForLoanPane, 350, 250);
                applyForLoanStage.setScene(applyForLoanScene);
                applyForLoanStage.show();
            });

            Button viewLoanStatusButton = new Button("View loan status");
            viewLoanStatusButton.setPrefWidth(200);

            viewLoanStatusButton.setOnAction(viewStatusEvent -> {
            loggedInUser.viewLoanStatus();
            });

            Button viewLoanHistoryButton = new Button("View loan history");
            viewLoanHistoryButton.setPrefWidth(200);

            viewLoanHistoryButton.setOnAction(viewHistoryEvent -> {
                loggedInUser.viewLoanHistory();

            });
            Button repayLoanButton = new Button("Repay a loan");
            repayLoanButton.setPrefWidth(200);
            repayLoanButton.setOnAction(repayEvent -> {
                Stage repayStage = new Stage();
                GridPane repayPane = new GridPane();
                repayPane.setAlignment(Pos.CENTER);
                repayPane.setPadding(new Insets(20));

                Label repayLabel = new Label("Enter the amount to repay:");
                TextField repaymentAmountField = new TextField();
                Button confirmRepaymentButton = new Button("Repay");

                Queue<Integer> loanRequests = loggedInUser.getLoanRequests();

                confirmRepaymentButton.setOnAction(confirmEvent -> {
                    try {
                        int repaymentAmount = Integer.parseInt(repaymentAmountField.getText());

                        loggedInUser.repayLoan(repaymentAmount); // Call the repayLoan function with the repayment amount
                        repayStage.close();
                    } catch (NumberFormatException ex) {
                        System.out.println("Please enter a valid amount.");
                    }
                });

                repayPane.add(repayLabel, 0, 0);
                repayPane.add(repaymentAmountField, 0, 1);
                repayPane.add(confirmRepaymentButton, 0, 2);

                Scene repayScene = new Scene(repayPane, 300, 200);
                repayStage.setScene(repayScene);
                repayStage.show();
            });
            Button backToMenuButton = new Button("Back to Operation menu");
            backToMenuButton.setPrefWidth(200);

            backToMenuButton.setOnAction(backEvent -> {
                loanStage.close();
            });


            loanPane.add(loanMenuLabel, 0, 0);
            loanPane.add(applyForLoanButton, 0, 1);
            loanPane.add(viewLoanStatusButton, 0, 2);
            loanPane.add(viewLoanHistoryButton, 0, 3);
            loanPane.add(repayLoanButton, 0, 4);
            loanPane.add(backToMenuButton, 0, 5);

            Scene loanScene = new Scene(loanPane, 400, 300);
            loanStage.setScene(loanScene);
            loanStage.show();
        });
        Button logoutButton = new Button("Logout");
        logoutButton.setPrefWidth(200);
        logoutButton.setOnAction(e->{
            stage.setScene(scene1);
            System.out.println("Log out Successfully: ");
        });

        operationsMenu.add(operationsLabel, 0, 0);
        operationsMenu.add(withdrawButton, 0, 1);
        operationsMenu.add(depositButton, 0, 2);
        operationsMenu.add(transferButton, 0, 3);
        operationsMenu.add(loanOperationsButton, 0, 4);
        operationsMenu.add(logoutButton, 0, 5);




        stage.setScene(scene1);
             stage.show();
    };
    public static void main(String[] args) {
        launch();
    }
}