package com.example.bankstimulation;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

class User {
    private String name;
    private String mobilePhone;
    private String cnic;
    private String username;
    private String password;
    private String email;
    private int balance;
   public Queue<Integer> loanRequests;
    private Stack<Integer> loanHistory;
    static Scanner scanner = new Scanner(System.in);

    public User(String name, String mobilePhone, String cnic, String username, String password, String email, int balance) {
        this.name = name;
        this.mobilePhone = mobilePhone;
        this.cnic = cnic;
        this.username = username;
        this.password = password;
        this.email = email;
        this.balance = balance;
        this.loanRequests = new LinkedList<>();
        this.loanHistory = new Stack<>();
    }

    public Queue<Integer> getLoanRequests() {
        return loanRequests;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public Stack<Integer> getLoanHistory() {
        return loanHistory;
    }

    public void setLoanHistory(Stack<Integer> loanHistory) {
        this.loanHistory = loanHistory;
    }

    public void setLoanRequests(Queue<Integer> loanRequests) {
        this.loanRequests = loanRequests;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getBalance() {
        return balance;
    }
    public void deposit(int amount) {
        do {
            if (amount <= 0) {
                System.out.println("Please enter a valid deposit amount greater than 0.");
            } else {
                this.balance += amount;
                break;
            }
        } while (true);
    }

    public boolean withdraw(int amount) {
        do {
            if (amount <= 0) {
                System.out.println("Please enter a valid withdrawal amount greater than 0.");
                break;
            } else if (this.balance < amount) {
                System.out.println("Insufficient balance for withdrawal.");
                break;
            } else {
                this.balance -= amount;
                return true;
            }
        } while (true);
        return false;
    }

    public boolean moneyTransfer(User recipient, int transferAmount) {
        do {
            if (transferAmount <= 0) {
                System.out.println("Please enter a valid transfer amount greater than 0.");
                break;
            }

            if (withdraw(transferAmount)) {
                recipient.deposit(transferAmount);
                return true;
            } else {
                System.out.println("Transfer failed. Insufficient balance or invalid amount.");
                break;
            }
        } while (true);
        return false;
    }

    public void viewLoanHistory() {
        if (loanHistory.isEmpty()) {
            System.out.println("No loan history.");
        } else {
            System.out.println("Loan history:");

            int totalRequested = 0;
            int totalRepaid = 0;

            for (int loanAmount : loanHistory) {
                totalRequested += loanAmount;

                // Check if the loan has been fully repaid
                if (totalRepaid >= totalRequested) {
                    System.out.println("- Requested: " + loanAmount + ", Approved: " + loanAmount + ", Repaid: " + totalRepaid);
                    System.out.println("  Status: Fully Paid");
                } else {
                    System.out.println("- Requested: " + loanAmount + ", Approved: " + loanAmount + ", Repaid: " + totalRepaid);
                    System.out.println("  Status: Unpaid");
                }

                totalRepaid += loanAmount;
            }
        }
    }
    public void applyForLoan() {
        if (!loanRequests.isEmpty()) {
            System.out.println("Loan request denied. You have pending dues.");
            return;
        }

        System.out.print("Enter the requested amount for the loan: ");
        int requestedAmount = scanner.nextInt();

        if (requestedAmount <= 2 * balance) {
            System.out.println("Loan request approved. Amount: " + requestedAmount);
            loanRequests.offer(requestedAmount);
        } else {
            System.out.println("Loan request denied. Requested amount exceeds the allowed limit.");
        }
    }

    public void viewLoanStatus() {
        if (loanRequests.isEmpty()) {
            System.out.println("No pending loan requests.");
        } else {
            int pendingLoanAmount = loanRequests.peek();
            int repaidLoanAmount = loanHistory.isEmpty() ? 0 : loanHistory.stream().mapToInt(Integer::intValue).sum();
            int remainingLoanAmount = Math.max(pendingLoanAmount - repaidLoanAmount, 0);

            System.out.println("Remaining loan amount: " + (loanRequests.isEmpty() ? 0 : loanRequests.peek()));
        }
    }


    public boolean repayLoan(int repaymentAmount) {
        if (loanRequests.isEmpty()) {
            System.out.println("No pending loan amount to repay.");
            return false;
        }

        int pendingLoanAmount = loanRequests.peek();

        if (repaymentAmount <= pendingLoanAmount) {
            balance -= repaymentAmount;
            loanHistory.push(repaymentAmount);

            if (repaymentAmount == pendingLoanAmount) {
                loanRequests.poll(); // Fully repaid, remove from pending loans
                System.out.println("Loan fully repaid. No pending loan amount.");
            } else {
                // Update the remaining loan amount in the queue
                int remainingLoanAmount = pendingLoanAmount - repaymentAmount;
                loanRequests.poll();
                loanRequests.offer(remainingLoanAmount);

                System.out.println("Partial loan repayment successful. Remaining loan amount: " + remainingLoanAmount);
            }

            return true; // Indicate successful repayment
        } else {
            System.out.println("Invalid repayment amount. You cannot repay more than the pending loan amount.");
            return false; // Indicate failed repayment
        }
    }

}

