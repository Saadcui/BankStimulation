package com.example.bankstimulation;

public class UserNode {
    private User data;
    private UserNode next;
    private UserNode prev;

    public UserNode(User data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }

    public User getData() {
        return data;
    }

    public UserNode getNext() {
        return next;
    }

    public void setNext(UserNode next) {
        this.next = next;
    }

    public UserNode getPrev() {
        return prev;
    }

    public void setPrev(UserNode prev) {
        this.prev = prev;
    }
}
