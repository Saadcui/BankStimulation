    package com.example.bankstimulation;

    import java.util.Scanner;

    class UserList {
        private UserNode head;
        static Scanner scanner = new Scanner(System.in);

        public UserNode getHead() {
            return head;
        }

        public void setHead(UserNode head) {
            this.head = head;
        }

        public boolean usernameExists(String username) {
            if (head == null) {
                return false; // List is empty, username doesn't exist
            }

            UserNode current = head;
            do {
                if (current.getData().getUsername().equals(username)) {
                    return true; // Username already exists
                }
                current = current.getNext();
            } while (current != head);
            return false; // Username doesn't exist
        }

        public void createAccount(String name, String mobilePhone, String cnic, String username, String password, String email, int balance) {
            Scanner scanner = new Scanner(System.in);

            do {
                if (balance <= 0) {
                    System.out.println("Please enter a valid initial balance greater than 0.");
                    System.out.print("Enter initial balance: ");
                    balance = scanner.nextInt();
                } else {
                    if (usernameExists(username)) {
                        System.out.println("Username already exists. Please choose a different username.");
                        return;
                    }

                    User newUser = new User(name, mobilePhone, cnic, username, password, email, balance);
                    insert(newUser);
                    System.out.println("Account created successfully!");
                    break;
                }
            } while (true);
        }


        public User login(String enteredUsername,String enteredPassword) {

            UserNode current = head;
            while (current != null) {
                User user = current.getData();
                if (user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword)) {
                    System.out.println("Login successful!");
                    return user;
                }
                current = current.getNext();
            }

            System.out.println("Invalid username or password.");
            return null;
        }

        public void insert(User data) {
            UserNode newNode = new UserNode(data);

            if (head == null) {
                head = newNode;
                newNode.setNext(head);
                newNode.setPrev(head);
            } else {
                UserNode last = head.getPrev();
                last.setNext(newNode);
                newNode.setPrev(last);
                newNode.setNext(head);
                head.setPrev(newNode);
            }
        }
        public User searchUserByName(String username) {
            if (head == null) {
                return null; // List is empty, user not found
            }

            UserNode current = head;
            do {
                User user = current.getData();
                if (user.getUsername().equals(username)) {
                    return user; // User found
                }
                current = current.getNext();
            } while (current != head);

            return null; // User not found
        }
    }
